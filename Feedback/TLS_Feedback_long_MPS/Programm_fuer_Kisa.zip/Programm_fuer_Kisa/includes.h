#ifndef __includes__
#define __includes__

#pragma GCC system_header
#include <string>
#include <iostream>
#include <sys/stat.h>
#include <fstream>
#include <vector>
#include <math.h>   
#include <time.h>
#include <stdio.h>
#include "itensor/all.h"

#endif
